import { stringParaEntradaDeData } from "@/utils/converters";

export default class Produto {
    id: number | null;
    produto: string;
    categoria: string;
    marca: string;
    tamanho: string;
    data: string;
    valor: string;
    observacao: string;

    constructor(id: number | null, produto: string, categoria: string, marca: string, tamanho: string, data: string,
        valor: string, observacao: string) {
        this.id = id;
        this.produto = produto;
        this.categoria = categoria;
        this.marca = marca;
        this.tamanho = tamanho;
        this.data = data;
        this.valor = valor;
        this.observacao = observacao;
    }

    static geraProdutosMock() {
        return [
          new Produto(1, "Ração", "Ração Seca", "Golden", "10 kg", "31.08.2024", "39.58", "NF 001"),

          new Produto(2, "Ração", "Ração Úmida", "Pedigree", "7 kg", "31.07.2024", "62.32", "NF 002"),

          new Produto(3, "Shampoo", "Higiene", "Pedigree", "500 ml", "31.07.2024", "29.36", "NF 002"),

          new Produto(4, "Petisco", "Petisco", "Golden", "150 gr", "12.03.2024", "12.02", "NF 003"),
        ]
      }

      static vazio(): Produto {
        return new Produto(null, "", stringParaEntradaDeData(""), "", "", "", "", "");
      }
  }



