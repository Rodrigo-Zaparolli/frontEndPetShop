export default function Home() {
  return (
    <div>
      <h2>Sistema de Produto Inicio</h2>
    </div>
  )
}
