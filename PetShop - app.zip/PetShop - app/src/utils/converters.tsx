export function stringParaEntradaDeData (data: string) {
    if (data) {
        return new Date(data).toString().split('T')[0]
    }
    return new Date().toISOString().split('T')[0]
}