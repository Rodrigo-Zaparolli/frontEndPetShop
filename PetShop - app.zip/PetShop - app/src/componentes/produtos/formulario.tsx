import Produto from "@/core/Produto";
import Entrada from "./entrada";
import { useState } from "react";
import { stringParaEntradaDeData } from "@/utils/converters";
import Botao from "./botao";

interface FormularioProps {
    produto: Produto
    produtoMudou?: (produto: Produto) => void
    cancelado?: () => void
}

export default function Formulario(props: FormularioProps) {
    const id = props.produto?.id
    const [produto, setProduto] = useState(props.produto?.produto)
    const [categoria, setCategoria] = useState(props.produto?.categoria)
    const [marca, setMarca] = useState(props.produto?.marca)
    const [tamanho, setTamanho] = useState(props.produto?.tamanho)
    const [data, setData] = useState(props.produto?.data)
    const [valor, setValor] = useState(props.produto?.valor)
    const [observacao, setObservacao] = useState(props.produto?.observacao)

    return (
        <div>
            {id ? (<Entrada texto="id" valor={id} somenteLeitura></Entrada>) : false}
            <Entrada texto="Produto" valor={produto} onChange={setProduto}></Entrada>
            <Entrada texto="Categoria" valor={categoria} onChange={setCategoria}></Entrada>
            <Entrada texto="Marca" valor={marca} onChange={setMarca}></Entrada>
            <Entrada texto="Tamanho" valor={tamanho} onChange={setTamanho}></Entrada>
            <Entrada texto="Data" tipo="date" valor={stringParaEntradaDeData(data)} onChange={setData}></Entrada>
            <Entrada texto="Valor" valor={valor} onChange={setValor}></Entrada>
            <Entrada texto="Observacao" valor={observacao} onChange={setObservacao}></Entrada>
            <div className="flex justify-end mt-5">
                <Botao className="mr-3" cor="bg-gradient-to-bl from-green-800 via-green-400 to-green-800"
                    onClick={() => props.produtoMudou?.(new Produto(
                        id, produto, categoria, marca, tamanho, data, valor, observacao))}>
                    {id ? 'Alterar' : 'Salvar'}
                </Botao>
                <Botao cor="bg-gradient-to-r from-gray-200 to-gray-700"
                    onClick={props.cancelado}>
                    Cancelar
                </Botao>
            </div>
        </div>
    )
}