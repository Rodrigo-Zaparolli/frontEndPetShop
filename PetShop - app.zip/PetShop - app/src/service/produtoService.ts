import Produto from '../core/Produto';

let produtosList: Produto[] = [
  
  new Produto(1, "Ração", "Ração seca", "Golden", "10 kg", "31.08.2024", "39.58", "NF 001" ),

  new Produto(2, "Ração", "Ração Úmida", "Pedigree", "7 kg", "31.07.2024", "62.32", "NF 002"),

  new Produto(3, "Shampoo", "Higiene", "Pedigree", "500 ml", "31.07.2024", "29.36", "NF 002"),

  new Produto(4, "Petisco", "Petisco", "Golden", "150 gr", "12.03.2024", "12.02", "NF 003"),
]
let proximoId = produtosList.length + 1;

export const fetchProdutos = async (): Promise<Produto[]> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    return produtosList;
  } catch (error) {
    throw new Error('Erro ao buscar produto');
  }
};

export const cadastrarProduto = async (novoProduto: Produto): Promise<Produto> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    novoProduto.id = proximoId++;
    produtosList.push(novoProduto);
    return novoProduto;
  } catch (error) {
    console.error("Erro ao cadastrar produto:", error);
    throw error;
  }
};


export const atualizarProduto = async (produtoAtualizado: Produto): Promise<Produto> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    const index = produtosList.findIndex((produto) => produto.id === produtoAtualizado.id);
    if (index !== -1) {
      produtosList[index] = produtoAtualizado;
      return produtoAtualizado;
    } else {
      throw new Error('Produto não encontrado');
    }
  } catch (error) {
    console.error("Erro ao atualizar Produto:", error);
    throw error;
  }
};

export const excluirProduto = async (id: number): Promise<void> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    produtosList = produtosList.filter((produto) => produto.id !== id);
  } catch (error) {
    console.error("Erro ao excluir produto:", error);
    throw error;
  }
};