import React from "react";

export default function Navbar(props: any) {
    return (
        <>
            <nav className="font-sans flex flex-col text-center sm:flex-row sm:text-left sm:justify-between py-6 px-8 bg-gray-800 text-stone-100 shadow sm:items-baseline w-full" style={{ backgroundColor: 'green' }}>
                <div className="mb-3 sm:mb-2">
                    <strong>Sistema de cadastro - PetShop</strong>
                </div>
                <div>

                    <a href="/" className="text-lg no-underline hover:text-amber-300 ml-4">
                    <strong> Home </strong></a>


                    <a href="/produtos" className="text-lg no-underline hover:text-amber-300 ml-4">
                    <strong> Produtos </strong></a>

                    <a href="/" className="text-lg no-underline hover:text-amber-300 ml-4">
                    <strong> Estoque </strong></a>

                    <a href="/" className="text-lg no-underline hover:text-amber-300 ml-4">
                    <strong> Clientes </strong></a>

                </div>
            </nav>
        </>
    );
}