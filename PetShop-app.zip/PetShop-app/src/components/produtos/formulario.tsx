import Produto from "@/core/Produto";
import Entrada from "./entrada";
import { useState } from "react";
import Botao from "./botao";

interface FormularioProps {
    produto: Produto
    produtoMudou?: (produto: Produto) => void
    cancelado?: () => void
}

export default function Formulario(props: FormularioProps) {
    const id = props.produto?.id
    const [produto, setProduto] = useState(props.produto?.produto)
    const [categoria, setCategoria] = useState(props.produto?.categoria)
    const [marca, setMarca] = useState(props.produto?.marca)
    const [tamanho, setTamanho] = useState(props.produto?.tamanho)
    const [data, setData] = useState(props.produto?.data)
    const [valor, setValor] = useState(props.produto?.valor)
    const [observacao, setObservacao] = useState(props.produto?.observacao)

    return (
        <div>
            <Entrada texto="Produto" valor={produto} onChange={setProduto}></Entrada>
            <Entrada texto="Categoria" valor={categoria} onChange={setCategoria}></Entrada>
            <Entrada texto="Marca" valor={marca} onChange={setMarca}></Entrada>
            <Entrada texto="Tamanho" valor={tamanho} onChange={setTamanho}></Entrada>
            <Entrada texto="Data" tipo="date" valor={data} onChange={setData}></Entrada>
            <Entrada texto="Valor" valor={valor} onChange={setValor}></Entrada>
            <Entrada texto="Observacao" valor={observacao} onChange={setObservacao}></Entrada>
            <div className="flex justify-end mt-5">
                <Botao className="mr-3" cor="bg-gradient-to-bl from-green-900 via-green-400 to-green-900 hover:text-amber-300"
                    onClick={() => props.produtoMudou?.(new Produto(
                        id, produto, categoria, marca, tamanho, data, valor, observacao))}>
                    {id ? 'Alterar' : 'Salvar'}
                </Botao>
                <Botao cor="bg-gradient-to-r from-gray-400 to-gray-800 hover:text-rose-900"
                    onClick={props.cancelado}>
                    Cancelar
                </Botao>
            </div>
        </div>
    )
}

