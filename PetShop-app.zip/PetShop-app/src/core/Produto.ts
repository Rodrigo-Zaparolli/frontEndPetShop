import { stringParaEntradaDeData } from "@/utils/converters";

export default class Produto {
  id: number | null;
  produto: string;
  categoria: string;
  marca: string;
  tamanho: string;
  data: string;
  valor: string;
  observacao: string;

  constructor(id: number | null, produto: string, categoria: string, marca: string, tamanho: string, data: string,
    valor: string, observacao: string) {
    this.id = id;
    this.produto = produto;
    this.categoria = categoria;
    this.marca = marca;
    this.tamanho = tamanho;
    this.data = data;
    this.valor = valor;
    this.observacao = observacao;
    }

    static geraProdutosMock() {
        return [

          new Produto(1, "Ração", "Ração Seca", "Golden", "10 kg", "2023-12-12", "39.58", "NF 001"),

          new Produto(2, "Ração", "Ração Úmida", "Pedigree", "7 kg", "2024.07.31.", "62.32", "NF 002"),
        
          new Produto(3, "Ração", "Ração Seca", "Pedigree", "15 kg", "2024.07.20", "52.36", "NF 002"),
        
          new Produto(4, "Ração", "Ração Úmida", "Golden", "10 kg", "2025.03.01", "42.32", "NF 003"),
        
          new Produto(5, "Petisco", "Petisco", "Golden", "150 gr", "2025.03.01", "12.02", "NF 003"),
        
          new Produto(6, "Sachê", "Petisco", "Pedigree", "150 gr", "2025.03.01", "12.9.25", "NF 003"),
        
          new Produto(7, "Coleira", "Acessórios", "Seresto", "Un", "2025.03.01", "275.69", "NF 003"),
        
          new Produto(8, "Shampoo", "Higiene", "Sanol", "750 ml", "2025.03.01", "12.35.59", "NF 003"),
        ]
      }


    static vazio(): Produto {
      return new Produto(null, "",  "", "", "", "", "", "");
    }
}

