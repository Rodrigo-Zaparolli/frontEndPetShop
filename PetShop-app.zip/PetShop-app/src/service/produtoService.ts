import Produto from '../core/Produto';


let produtosList: Produto[] = [
  
  new Produto(1, "Ração", "Ração Seca", "Golden", "10 kg", "2023-12-12", "39.58", "NF 001"),

  new Produto(2, "Ração", "Ração Úmida", "Pedigree", "7 kg", "2024.07.31.", "62.32", "NF 002"),

  new Produto(3, "Ração", "Ração Seca", "Pedigree", "15 kg", "2024.07.20", "52.36", "NF 002"),

  new Produto(4, "Ração", "Ração Úmida", "Golden", "10 kg", "2025.03.01", "42.32", "NF 003"),

  new Produto(5, "Petisco", "Petisco", "Golden", "150 gr", "2025.03.01", "12.02", "NF 003"),

  new Produto(6, "Sachê", "Petisco", "Pedigree", "150 gr", "2025.03.01", "12.9.25", "NF 003"),

  new Produto(7, "Coleira", "Acessórios", "Seresto", "Un", "2025.03.01", "275.69", "NF 003"),

  new Produto(8, "Shampoo", "Higiene", "Sanol", "750 ml", "2025.03.01", "12.35.59", "NF 003"),
]
let proximoId = produtosList.length + 1;

export const fetchProdutos = async (): Promise<Produto[]> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    return produtosList;
  } catch (error) {
    throw new Error('Erro ao buscar produtos');
  }
};

export const cadastrarProduto = async (novoProduto: Produto): Promise<Produto> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    novoProduto.id = proximoId++;
    produtosList.push(novoProduto);
    return novoProduto;
  } catch (error) {
    console.error("Erro ao cadastrar produto:", error);
    throw error;
  }
};

export const atualizarProduto = async (produtoAtualizado: Produto): Promise<Produto> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    const index = produtosList.findIndex((produto) => produto.id === produtoAtualizado.id);
    if (index !== -1) {
      produtosList[index] = produtoAtualizado;
      return produtoAtualizado;
    } else {
      throw new Error('Produto não encontrada');
    }
  } catch (error) {
    console.error("Erro ao atualizar produto:", error);
    throw error;
  }
};

export const excluirProduto = async (id: number): Promise<void> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    produtosList = produtosList.filter((produto) => produto.id !== id);
  } catch (error) {
    console.error("Erro ao excluir produto:", error);
    throw error;
  }
};

